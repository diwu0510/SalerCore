﻿using System;

namespace Zodo.Saler.Application
{
    public partial class DeptSalerDto
    {
        /// <summary>
        /// Id
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// DeptId
        /// </summary>
        public int DeptId { get; set; }

        /// <summary>
        /// SalerId
        /// </summary>
        public int SalerId { get; set; }

    }
}
