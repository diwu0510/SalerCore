﻿using System;

namespace Zodo.Saler.Application
{
    public partial class DataItemDto
    {
        /// <summary>
        /// Id
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// 键
        /// </summary>
        public string K { get; set; }

        /// <summary>
        /// 值
        /// </summary>
        public string V { get; set; }

    }
}
