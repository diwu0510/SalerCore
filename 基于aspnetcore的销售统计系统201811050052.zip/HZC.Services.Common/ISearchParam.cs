﻿using HZC.Database;

namespace HZC.Common.Services
{
    public interface ISearchParam
    {
        MySearchUtil ToSearchUtil();
    }
}
