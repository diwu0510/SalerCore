﻿namespace HZC.Common.Services
{
    public class DataItemDto
    {
        public string K { get; set; }

        public string V { get; set; }
    }
}
