﻿namespace HZC.Core
{
    /// <summary>
    /// 基础系统用户
    /// </summary>
    public interface IAppUser
    {
        int Id { get; set; }

        string Name { get; set; }
    }
}
